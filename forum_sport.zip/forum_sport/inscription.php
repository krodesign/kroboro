<!DOCTYPE html>
<?php 
require_once("sql_select_mysgli_oo.php"); 
?>
<html>
<head>
	<title></title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="style.css">
  <link rel="stylesheet" type="text/css" href="style_rech.css">
</head>
<body>
	<div class="conteneur"> 
    <div class="logo">
    </div>
      <div class="en_tete">
           <div class="menu">
              <ul>
                 <li><a href="index.php">Accueil</a></li>
                 <li><a href="recherche.php">Recherche</a></li>
                 <li class="bv">Bienvenu Seyni Toure sur notre site Forum Sport</li>
              </ul>
           </div>
           <div class="titre_page">Inscription</div>
          
          <div class="section">       
     <form>
      <fieldset>
      <legend>Page d'Inscription</legend>
      <table>
        <tr>
           <td><h1>Nom</h1></td>
        </tr>
        <tr>
           <td><input type="text" name="nom" size="50"></td>
        </tr>
        <tr>
          <td><h1>Prénom</h1></td>
        </tr>
        <tr>
           <td><input type="text" name="prenom" size="50"></td>
        </tr>
        <tr>
           <td><h1>Departement</h1></td>
        </tr>
        <tr>
           <td><input type="text" name="depart" size="50"></td>
        </tr>
        <tr>
          <td><h1>E-mail</h1></td>
        </tr>
        <tr>
           <td><input type="text" name="mail" size="50"></td>
        </tr>
        <tr>
         <td><h1>Mot de passe</h1></td>
        </tr>
        <tr>
           <td><input type="password" name="mp" size="50"></td>
        </tr>
      </table>
      </fieldset>
   </form> 
          
        <fieldset>
          <legend>Sport</legend>
          <table>
            <tr>
              <td><h1>Sport</h1></td>
              <td>
              <select name="design">
                <?php   

                while($data=mysqli_fetch_array($res)) {
              //on affiches les resultats
                  echo "<option value='".$data['design']."'>".$data['design']."</option>";
                   }
                ?>
              </select>
              </td>
            </tr>
            <tr>
            <td><h1>Niveau</h1></td>
            <td>
              <select name="design">
                 <option value="debutant">debutant</option>
                 <option value="confifmé">confifmé</option>
                 <option value="Pro">Pro</option>
                 <option value="Supperter">Supporter</option>
              </select>
              </td>
            </tr>
          </table>
        </fieldset>  
        <tr>
          <td><input type="submit" value="Se connecter"></td>
        </tr>
          <tr>
          <td><input type="reset" value="Annuler"></td>
        </tr>
      </div>
            
       <footer>XX</footer>      
   </div>
</body>
</html>
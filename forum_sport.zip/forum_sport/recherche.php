<!DOCTYPE html>
<?php 
require_once("sql_select_mysgli_oo.php"); 
?>
<html>
<head>
	<title></title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<div class="conteneur"> 
    <div class="logo">
    </div>
      <div class="en_tete">
           <div class="menu">
              <ul>
                 <li><a href="index.php">Accueil</a></li>
                 <li><a href="inscription.php">Inscription</a></li>
                 <li class="bv">Bienvenu Seyni Toure sur notre site Forum Sport</li>
              </ul>
           </div>
           <div class="titre_page">Recherche</div>
           
     </div> 
     <footer>XX</footer>       
   </div>
</body>
</html>
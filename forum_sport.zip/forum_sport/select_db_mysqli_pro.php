<!DOCTYPE html>
<html>
<head>
	<title>selection de la base de donnee</title>
	<h1>select_db_mysqli_pro</h1>
</head>
<body>
   <?php
//1:connexion au serveur
//2:selection de la base de donnee
//3:requete
//4:explotation
//5:deconnexion	   

//Paramètres de connexion
$servername = "localhost";
$username = "root";
$password = "";


//On établit la connexion
$conn= mysqli_connect($servername, $username, $password);

//On vérifie la connexion
if(!$conn){
die("Erreur : ".mysqli_connect_error());
}
echo"Connexion au serveur réussie <br>";

//on selectionne la base de donnée en "connexion"
if(mysqli_select_db($conn,"bd_sport")) {
echo "Base de donnée selectionné";
}
else
echo "erreur de selection de la base de donnée";
mysqli_close($conn);
?>
</body>
</html>

<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
    <?php
require_once("Connexion_au_serveur.php");
 //1:connexion au serveur
//2:selection de la base de donnee
//3:requete
//4:explotation
//5:deconnexion

    //On établit la connexion
$conn = mysqli_connect($servername, $username, $password);

    //On vérifie la connexion
if(!$conn){
	die("Erreur : ".mysqli_connect_error()); 
}
echo"connexion au serveur réussie <br>";

    //on selectionne la base de donnée en "connexion"
$conn->select_db("bd_sport");

     //on crée la requete
$req="SELECT * FROM sport";
//on envoie la requete

//($res on la creer cette variable pour recuperer les donnees)
$res=$conn->query($req);
?>
</body>
</html>

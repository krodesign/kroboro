<!DOCTYPE html>
<html>
<head>
	<title>Connexion au serveur Mysqli procedural</title>
	<h1>Connexion_au_serveur.php</h1>
</head>
<body>
  <?php
//1:connexion au serveur
//2:selection de la base de donnee
//3:requete
//4:explotation
//5:deconnexion

    //Paramétre de connexion 
$servername="localhost";
$username="root";
$password="";

   //Etablir la connexion 
$conn=mysqli_connect($servername, $username, $password);

  //on verifie la connexion
if (!$conn) {
	die("Erreur:".mysql_connect_error());
  } 
echo "Connexion reussie"; 
  ?>
</body>
</html>

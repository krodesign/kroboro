<!DOCTYPE html>
<?php 
require_once("sql_select_mysgli_oo.php"); 
?>
<html>
<head>
	<title></title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<div class="conteneur"> 
    <div class="logo">
    </div>
      <div class="en_tete">
           <div class="menu">
              <ul>
                 <li><a href="inscription.php">Inscription</a></li>
                 <li><a href="recherche.php">Recherche</a></li>
                 <li class="bv">Bienvenu Seyni Toure sur notre site Forum Sport</li>
              </ul>
           </div>
           <div class="titre_page">Accueil</div>
           <div class="contenu">
            
               <div class="liste_sports">
                    <?php 
      //on va scanner tous les enregistrements un par un
echo "<table border=1 width=600>";
echo "<tr><td>Numero</td><td>designation</td></tr>";
while($data=mysqli_fetch_array($res)) {
//on affiches les resultats
echo "<tr><td>".$data["id_sport"]."</td><td>".$data["design"]."</td></tr>";}
echo "<table>";
    ?>  </div>
                
              
               
               <div class="formulaire" >
               <form>
                  <table border="1">
                     <tr>
                        <td><label>Mail</label></td>
                        <td><input type="mail" name="mail"></td>
                     </tr>
                     <tr>
                        <td><label>Mot de passe</label></td>
                        <td><input type="password" name="mp"></td>
                     </tr>
                     <tr>
                     <td colspan="2"><button type="submut">Connexion</button></td>
                     </tr>
                     
                  </table>
               </form>
               <div>
           </div>
        </div>
       <footer>XX</footer> 
   </div>
</body>
</html>